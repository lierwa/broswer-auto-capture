# AI Connect React

复用 opencode 的完整聊天界面：消息、Markdown、思考过程、工具状态、内容卡片、输入框、停止、重试、滚动及入场动画。模型设置与聊天从包根入口导入，一次引入编译样式即可。

```tsx
import { useState } from 'react'
import { ChatTimeline, ModelSettingsDialog, useAIChat } from '@agent-platform/ai-connect-react'
import type { AIChatTransport, AIClient, ModelSelection } from '@agent-platform/ai-connect-react'
import '@agent-platform/ai-connect-react/styles.css'

function Chat({ client, model, saveModel, transport, sessionId }: {
  client: AIClient
  model?: ModelSelection
  saveModel(value: ModelSelection): Promise<void>
  transport: AIChatTransport
  sessionId: string
}) {
  const [settingsOpen, setSettingsOpen] = useState(false)
  const chat = useAIChat({ resetKey: sessionId, model, transport })
  return <div style={{ height: '100%' }}>
    <ChatTimeline {...chat}
      theme={{ assistantName: '助手', composerPlaceholder: '输入消息' }}
      composerControls={<button onClick={() => setSettingsOpen(true)}>模型设置</button>}
    />
    <ModelSettingsDialog client={client} value={model} onChange={saveModel}
      open={settingsOpen} onOpenChange={setSettingsOpen} requiredSurface="directInvocation" />
  </div>
}
```

`transport` 接收 `{ model, messages, signal, onEvent }`，通过宿主已鉴权的业务接口调用服务端
`ai.forSubject(subject).generate()`，将同一次调用的 `AIEvent` 交给 `onEvent`，并在传输结束时完成 Promise。
HTTP/SSE/WebSocket 的选择由现有业务接口决定；SSE 数据可使用核心包的 `parseAIEventSSEData` 校验。
Provider 凭证保存在服务端。服务端仍需核对身份与模型权限。

`useAIChat` 提供内存消息、流式更新、停止与重试；`initialMessages` 在首次挂载或 `resetKey` 改变时载入。
已有消息存储或调用状态的宿主直接传 `messages/running/onSend/onStop/onRetry` 给 `ChatTimeline`。
每条消息提供稳定 `id`、`role`、`createdAt` 和 `content`；内容可为 Markdown 文本，或 text/reasoning/tool/content 部件。
`content` 部件接受宿主 React 内容，`fallbackText` 在该部件渲染失败时显示。持久化与会话列表由宿主维护。
模型适配器的输入能力仍适用：例如仅支持单轮输入的绑定不会因聊天 UI 而获得多轮能力。

宿主可通过以下接口调整已有界面：

- `appearance`: light、dark 或 inherit；默认继承宿主语义颜色。
- `className/style/partClassNames`: 根容器和 viewport、content、composer 的样式。
- `--chat-font-family`、`--chat-content-width`、`--chat-composer-width`: 字体与宽度。
- `theme`: 助手名字、头像、输入提示、输入框无障碍名称和双方消息样式。
- `composerControls/composerAccessory/emptyStateFooter`: 模型入口与业务控件插槽。
- `draft`: 宿主控制草稿；`readOnly` 隐藏输入区域，`disabled` 禁止编辑与发送。
- `composerSubmitMode`: 默认 `modified-enter` 保持现有快捷键；设为 `enter` 时 Enter 发送、Shift+Enter 换行，并保留输入法组合态保护。

完整 Timeline 的父容器需要明确高度。包样式限定在组件内；宿主自己的 Radix 控件应自行引入 Radix 样式。
Tailwind 宿主可使用 `@import '@agent-platform/ai-connect-react/styles.css' layer(components)`，让本地 utilities 保持覆盖优先级。

`ChatTimelineView` 暴露原 InteractiveTimeline 的完整受控契约，用于已有 Conversation projection、Question/Card/Artifact 注册表的宿主；高级类型与注册函数由 `@agent-platform/ai-connect-react/chat` 导出。
`ChatTimelineMessages` 复用同一消息呈现，用于已有页面滚动容器内的只读消息列表。
`AIInvocationTimeline` 接收 `AIEvent[]`，通过统一投影后使用相同消息组件展示调用记录。
opencode 的 `@agent-platform/ui` 保留平台状态适配与既有公开入口，聊天呈现实现由本包拥有。

账号设置也可以独立使用：

```tsx
import { createAIClient } from '@agent-platform/ai-connect/client'
import { AccountSettings, ModelPicker, ModelSettingsDialog } from '@agent-platform/ai-connect-react'
import '@agent-platform/ai-connect-react/styles.css'

// 在组件外创建，或用 useMemo 保持引用稳定。
const client = createAIClient({ baseURL: '/api/ai' })

function Settings({ model, saveModel }) {
  return <>
    <AccountSettings client={client} value={model} onSelect={saveModel} />
    <ModelPicker client={client} value={model} onChange={saveModel} />
  </>
}
```

需要原生联网搜索的任务在受控弹窗声明能力名：

```tsx
<ModelSettingsDialog
  open={open}
  onOpenChange={setOpen}
  client={client}
  value={model}
  requiredSurface="directInvocation"
  requiredCapabilities={['nativeWebSearch', 'vision', 'structuredOutput']}
  onChange={saveModel}
/>
```

OAuth 授权成功后立即保存账号并加载模型目录，模型选择和能力验证在后续选择阶段完成。API key
连接仍验证用户明确填写的模型。弹窗在保存模型选择前调用服务端 fresh 能力验证；所有需求都 verified 才调用 `onChange`。模型明确不支持时
提示更换，认证、版本、网络或探针暂不可用时提示重试/重连；原选择保持不变。`requiredSurface`
也决定授权时创建 direct invocation managed profile，还是保留 agent session 的 Pi OAuth 路径。

`AccountSettings` 内部处理加载、授权事件订阅、提示输入、取消、连接测试和账号删除。
`onSelect` 可省略，此时只管理账号。`ModelPicker` 是受控组件，模型选择由业务保存；通过同一 client 连接、删除或刷新账号后，选择器会自动刷新目录。`refreshKey` 可用于业务主动触发额外刷新。

组件自带 Radix Theme 包装与编译 CSS，无需配置 Tailwind 扫描。可通过 `appearance="light" | "dark" | "inherit"` 设置主题；宿主也可提供已有语义 CSS 变量。认证请求可在 `createAIClient` 中注入 headers 或 authenticatedFetch；不要向浏览器发送 provider 凭证文件。

普通接入使用包根入口。`components/*` 保留已有细粒度导入的兼容性，调用方无需依赖组件文件布局。
