# AI Connect React

```tsx
import { createAIClient } from '@agent-platform/ai-connect/client'
import { AccountSettings, ModelPicker, ModelSettingsDialog } from '@agent-platform/ai-connect-react'
import '@agent-platform/ai-connect-react/styles.css'

// 在组件外创建，或用 useMemo 保持引用稳定。
const client = createAIClient({ baseURL: '/api/ai' })

function Settings({ model, saveModel }) {
  return <>
    <AccountSettings client={client} value={model} onSelect={saveModel} />
    <ModelPicker client={client} value={model} onChange={saveModel} />
  </>
}
```

需要原生联网搜索的任务在受控弹窗声明能力名：

```tsx
<ModelSettingsDialog
  open={open}
  onOpenChange={setOpen}
  client={client}
  value={model}
  requiredSurface="directInvocation"
  requiredCapabilities={['nativeWebSearch', 'vision', 'structuredOutput']}
  onChange={saveModel}
/>
```

弹窗先调用服务端 fresh 能力验证；所有需求都 verified 才调用 `onChange`。模型明确不支持时
提示更换，认证、版本、网络或探针暂不可用时提示重试/重连；原选择保持不变。`requiredSurface`
也决定授权时创建 direct invocation managed profile，还是保留 agent session 的 Pi OAuth 路径。

`AccountSettings` 内部处理加载、授权事件订阅、提示输入、取消、连接测试和账号删除。
`onSelect` 可省略，此时只管理账号。`ModelPicker` 是受控组件，模型选择由业务保存；通过同一 client 连接、删除或刷新账号后，选择器会自动刷新目录。`refreshKey` 可用于业务主动触发额外刷新。

组件自带 Radix Theme 包装与编译 CSS，无需配置 Tailwind 扫描。可通过 `appearance="light" | "dark" | "inherit"` 设置主题；宿主也可提供已有语义 CSS 变量。认证请求可在 `createAIClient` 中注入 headers 或 authenticatedFetch；不要向浏览器发送 provider 凭证文件。

`components/*` 为当前平台复用已有账号交互的细粒度入口，普通接入使用上述两个组件。
