# @agent-platform/pi-agent-session

Server-only Pi AgentSession adapter for trusted Agent Platform hosts.

The host owns canonical conversation and authoring state. This package owns only the private Pi execution session and exposes explicit accepted-step confirmation after the host commits a successful turn.

Ambient Pi resource discovery is disabled. An independent server host can opt into a pinned Pi
extension with `extensionTools: { sources, activeTools }`; Pi loads and executes the extension while
the adapter validates the exact tool allowlist and projects the existing typed tool lifecycle.
Provider/model selection and credentials remain outside this package.
