# Third-party notices

This package uses the Pi 1.0.0 runtime packages. Their respective licenses and notices apply.
