# AI Connect

在 Node 24+ 服务中接入自己的模型订阅账号或 API key。包负责账号授权、凭证保存与刷新、模型目录、能力验证，以及文本、图片输入和 JSON Schema 结构化生成。

```ts
import { createAI, localStore } from '@agent-platform/ai-connect/server'
import { mountAI } from '@agent-platform/ai-connect/fastify'

const ai = await createAI({ storage: localStore() }) // 默认使用当前系统用户目录下的 .ai-connect
// 宿主需要独立数据根时可改为 localStore({ directory: './data/ai' })。
await mountAI(app, {
  ai,
  prefix: '/api/ai',
  resolveSubject: request => auth.requireUserId(request), // 宿主现有鉴权函数
})

const result = await ai.forSubject(user.id).generate({
  model: task.model, // { connectionId, modelId, reasoningEffort }
  messages: [{ role: 'user', content: '请分析这段内容……' }],
  signal,
  onEvent(event) {
    if (event.type === 'text.delta') process.stdout.write(event.text)
  },
})
console.log(result.text, result.usage)
// 应用关闭时调用 ai.close()，取消仍在执行的授权和生成。
```

要求所选账号和模型提供原生联网搜索时，把需求放在同一次准确选择上：

```ts
const result = await ai.forSubject(user.id).generateObject({
  model: task.model,
  requiredCapabilities: ['nativeWebSearch', 'vision', 'structuredOutput'],
  messages: [{ role: 'user', content: task.prompt }],
  schema: task.schema,
  onEvent: event => task.events.publish(event),
})
```

ChatGPT 订阅由每个连接独立的 Codex managed profile 管理。`localStore()` 默认使用当前系统用户目录下的
`.ai-connect`；宿主可传入 `directory` 覆盖。账号 metadata、凭证文件和 managed profile 始终从同一个
最终目录派生；宿主存储 Adapter 需传入 `codexManagedProfiles.directory`。官方 App Server
负责浏览器 OAuth、refresh 和实际调用，AI Connect 不读取其认证文件。能力验证只在所选
profile 内运行无业务数据 probe；没有原生 search 完成事件就不会通过，也不会转用全局 Codex。
搜索完成事件包含同一次 thread/turn 的受限 HTTPS 结果 URL。确认选择会执行 fresh probe；短期缓存
只服务同一冻结绑定的执行复核。

排队任务可先调用 `forSubject(subjectId).prepareInvocation(...)`，持久化返回的 opaque id，再把
它传给 `generate({ prepared, ... })` 或 `generateObject({ prepared, ... })`。包在执行前重新核对
subject、connection、model catalog、credential、managed-profile registry 和 capability evidence
revision；变化后明确失败，不切换账号或模型。

`auth.requireUserId` 代表应用已有的认证逻辑，返回已验证的用户 ID。Fastify 4 与 5 使用相同 `mountAI`，现有鉴权、Origin/Host 检查和 hooks 继续生效。单用户本地服务也可在这些检查之后返回固定的本地 subject。不要从请求参数直接接受 subject。

其他 HTTP 框架使用 `ai.handle(request, { subjectId, basePath: '/api/ai' })`，传入标准 Request；包会移除挂载前缀。省略 basePath 时，请求路径从 `/provider-connections` 或 `/catalog` 开始。接口管理账号；业务模型调用在服务端通过 `forSubject().generate()` 执行，应用决定业务路由与费用权限。

浏览器客户端：

```ts
import { createAIClient } from '@agent-platform/ai-connect/client'
const client = createAIClient({ baseURL: '/api/ai', fetch: authenticatedFetch })
const { data, error } = await client.catalog()
const capability = await client.verifyCapabilities({ model, require: ['nativeWebSearch', 'vision', 'structuredOutput'] })
```

React 设置界面由 `@agent-platform/ai-connect-react` 提供。模型选择由业务保存，包不会自动切换账号或模型。使用端无需配置 Pi、OAuth 回调实现、SQLite schema 或依赖补丁。

`localStore` 为单机文件存储，使用 Node SQLite 与独立凭证文件；同一系统用户下使用默认目录的宿主共享存储根，所有查询按 subject 隔离。多进程的账号/凭证写入使用已有文件 lease；授权任务属于启动它的进程，多实例 HTTP 部署需要粘性路由。OAuth 的本机回调在服务进程所在机器，远程部署需核对厂商支持的登录方式。

`@agent-platform/ai-connect/browser` 是纯浏览器类型/解析入口。`integration/*` 为受信任服务端
集成接口，提供共享存储与 provider 装配，不能作为普通浏览器入口。Codex managed profile 的
bounded direct invocation 接受一个 text/image user turn；无法无损表达的 assistant history 明确失败。
Platform Main 的 `agentSession` 继续使用现有 Pi OAuth，direct-only 账号不会进入 Main 选择。

本仓库 Platform 在启动时调用 `createAI`，保留原数据库和凭证位置；实际设置页使用
`AccountSettings` 和 `ModelPicker`。已有 Run 快照通过服务端 `createModelGenerator(connection).generate()`
执行，和 `forSubject().generate()` 共用生成实现；Main 继续使用 Pi AgentSession。

构建、测试和打包（在源码仓库）：

```sh
bun --filter @agent-platform/ai-connect build
bun --filter @agent-platform/ai-connect-react build
bun --filter @agent-platform/ai-connect typecheck
node --test packages/ai-connect/tests/*.test.mjs
bun --filter @agent-platform/ai-connect pack
```

打包输出两个可安装 tarball 到`packages/ai-connect/artifacts`。同时安装两个 tarball 可在发布注册表前跨项目使用。构建产物内联锁定且已打补丁的 Pi 实现，其余 SDK 作为普通依赖安装。

在其他项目中安装本地构建产物：

```sh
npm install /path/to/agent-platform-ai-connect-0.3.0.tgz /path/to/agent-platform-ai-connect-react-0.3.0.tgz
```

独立 tarball 的已验证安装工具为 npm。本机完成 Node 24、Fastify 4/5、公开类型和浏览器构建验证；
本仓库已通过原有 ChatGPT 订阅完成公开生成入口与实际聊天入口的单轮调用。Windows CI 尚待执行。
