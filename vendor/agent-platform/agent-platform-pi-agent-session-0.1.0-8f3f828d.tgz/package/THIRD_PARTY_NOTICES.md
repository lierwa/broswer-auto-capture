# Third-party notices

This package uses the Pi 0.84.2 runtime packages. Their respective licenses and notices apply.
