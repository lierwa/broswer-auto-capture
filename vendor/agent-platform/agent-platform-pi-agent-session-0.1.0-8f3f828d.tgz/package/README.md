# @agent-platform/pi-agent-session

Server-only Pi AgentSession adapter for trusted Agent Platform hosts.

The host owns canonical conversation and authoring state. This package owns only the private Pi execution session and exposes explicit accepted-step confirmation after the host commits a successful turn.
